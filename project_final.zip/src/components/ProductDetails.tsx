import { ArrowLeft, Heart, ShoppingCart, Star, StarHalf } from 'lucide-react';
import { COLORS } from '../theme/constants';
import { Product } from '../data/mockData';
import { motion } from 'framer-motion';
import PaySlowBreakdown from './PaySlowBreakdown';

interface ProductDetailsProps {
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onBack: () => void;
  onAddToCart: (product: Product) => void;
  onPaySlow: (product: Product) => void;
}

export default function ProductDetails({ 
  product, 
  isWishlisted,
  onToggleWishlist,
  onBack, 
  onAddToCart,
  onPaySlow
}: ProductDetailsProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="fixed inset-0 z-[60] flex flex-col"
      style={{ backgroundColor: '#FFFFFF' }}
    >
      {/* Top Header */}
      <div className="flex items-center justify-between px-6 h-[70px] bg-white">
        <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-slate-50 transition-colors">
          <ArrowLeft size={24} style={{ color: COLORS.text }} />
        </button>
        <span className="font-bold text-lg" style={{ color: COLORS.text }}>Product Details</span>
        <button onClick={() => onToggleWishlist(product)} className="p-2 -mr-2">
          <Heart size={24} fill={isWishlisted ? COLORS.primary : 'transparent'} style={{ color: COLORS.primary }} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar pb-32">
        {/* Product Image Section */}
        <div className="px-6 mb-4">
          <div className="aspect-[4/3] rounded-[32px] bg-slate-50 overflow-hidden">
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Product Info Section */}
        <div className="px-6 mb-8">
          <div className="mb-2">
            <h1 className="text-2xl font-black mb-1" style={{ color: COLORS.text }}>{product.name}</h1>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1">
                <Star size={14} fill="#FFC107" color="#FFC107" />
                <span className="text-sm font-bold" style={{ color: COLORS.text }}>{product.rating}</span>
              </div>
              <span className="text-xs text-slate-400 font-bold uppercase tracking-widest">• {product.reviewCount} Reviews</span>
            </div>
          </div>
          <p className="text-sm font-medium mb-4" style={{ color: COLORS.secondaryText }}>{product.description}</p>
          <div className="text-3xl font-black" style={{ color: COLORS.primary }}>
            K{product.price.toLocaleString()}
          </div>
        </div>

        {/* Payment Calculator Section */}
        <div className="px-6 mb-12">
          <PaySlowBreakdown price={product.price} />
        </div>

        {/* Ratings & Reviews Section */}
        <div className="px-6 mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-black" style={{ color: COLORS.text }}>Ratings & Reviews</h2>
            <button className="text-xs font-black text-red-500 uppercase tracking-widest">See All</button>
          </div>

          <div className="flex items-center gap-8 mb-10">
            <div className="text-center">
              <div className="text-5xl font-black mb-1" style={{ color: COLORS.text }}>{product.rating}</div>
              <div className="flex items-center gap-0.5 justify-center mb-1">
                {[1, 2, 3, 4].map(i => <Star key={i} size={12} fill="#FFC107" color="#FFC107" />)}
                <StarHalf size={12} fill="#FFC107" color="#FFC107" />
              </div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{product.reviewCount} Ratings</p>
            </div>

            <div className="flex-1 space-y-2">
              {[5, 4, 3, 2, 1].map((star) => (
                <div key={star} className="flex items-center gap-3">
                  <span className="text-[10px] font-bold text-slate-400 w-2">{star}</span>
                  <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full rounded-full" 
                      style={{ 
                        backgroundColor: star >= 4 ? '#FFC107' : '#E2E8F0',
                        width: star === 5 ? '85%' : star === 4 ? '12%' : '1%'
                      }} 
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Review List */}
          <div className="space-y-8">
            {product.reviews.map((review) => (
              <div key={review.id} className="space-y-3 pb-8 border-b border-slate-50 last:border-0">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img 
                      src={review.userAvatar} 
                      alt={review.userName} 
                      className="w-10 h-10 rounded-full object-cover border-2 border-slate-50" 
                    />
                    <div>
                      <p className="text-sm font-bold" style={{ color: COLORS.text }}>{review.userName}</p>
                      <div className="flex items-center gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star 
                            key={i} 
                            size={10} 
                            fill={i < review.rating ? "#FFC107" : "transparent"} 
                            color={i < review.rating ? "#FFC107" : "#E2E8F0"} 
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{review.date}</span>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed italic">
                  "{review.comment}"
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Payment Trust Badges */}
      <div className="fixed bottom-[88px] left-0 right-0 px-6 py-2 bg-white/80 backdrop-blur-sm border-t border-slate-50 flex items-center justify-center gap-3 z-65">
         <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mr-1">Pay with Momo</span>
         <img src="/assets/aistudio/mtn-logo_4a74e1b2.png" alt="MTN" className="h-3.5 w-auto opacity-60" referrerPolicy="no-referrer" />
         <img src="/assets/aistudio/IMG_67974b16-294a-43a0-80f6-73f504675b27_a34625cb.png" alt="Airtel" className="h-3.5 w-auto opacity-60" referrerPolicy="no-referrer" />
         <img src="/assets/aistudio/IMG_d626c724-43a0-4510-a28d-3ef0ffc4e2d9_19320552.png" alt="Zamtel" className="h-3.5 w-auto opacity-60" referrerPolicy="no-referrer" />
      </div>

      {/* Fixed Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-6 bg-white border-t border-slate-100 flex items-center gap-4 z-70">
        <button 
          onClick={() => onAddToCart(product)}
          className="flex-1 h-14 rounded-2xl bg-black text-white font-bold text-base flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
        >
          <ShoppingCart size={20} />
          Add to Cart
        </button>
        <button 
          onClick={() => onPaySlow(product)}
          className="flex-1 h-14 rounded-2xl text-white font-bold text-base flex items-center justify-center active:scale-[0.98] transition-transform shadow-lg shadow-red-500/20"
          style={{ backgroundColor: COLORS.primary }}
        >
          Pay Slow
        </button>
      </div>
    </motion.div>
  );
}
