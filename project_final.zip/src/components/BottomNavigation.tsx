import { Store, ShoppingCart, History, Heart, User } from 'lucide-react';
import { COLORS } from '../theme/constants';

type TabType = 'shop' | 'cart' | 'history' | 'wishlist' | 'account';

interface BottomNavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

export default function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const tabs = [
    { id: 'shop' as const, label: 'Shop', Icon: Store },
    { id: 'cart' as const, label: 'Cart', Icon: ShoppingCart },
    { id: 'history' as const, label: 'History', Icon: History },
    { id: 'wishlist' as const, label: 'Wishlist', Icon: Heart },
    { id: 'account' as const, label: 'Account', Icon: User },
  ];

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 h-[80px] px-6 flex items-center justify-between z-50 border-t border-white/5"
      style={{ backgroundColor: COLORS.navBackground }}
    >
      {tabs.map(({ id, label, Icon }) => {
        const isActive = activeTab === id;
        return (
          <button
            key={id}
            onClick={() => onTabChange(id)}
            className="flex flex-col items-center gap-1.5 transition-all duration-300 relative py-2"
          >
            <Icon 
              size={22} 
              style={{ 
                color: isActive ? COLORS.primary : COLORS.inactiveIcon,
                strokeWidth: isActive ? 2.5 : 2
              }} 
            />
            <span 
              className={`text-[10px] ${isActive ? 'font-bold' : 'font-medium'}`}
              style={{ color: isActive ? COLORS.primary : COLORS.inactiveIcon }}
            >
              {label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
