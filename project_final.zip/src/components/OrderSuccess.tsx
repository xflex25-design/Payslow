import { CheckCircle2 } from 'lucide-react';
import { COLORS } from '../theme/constants';
import { motion } from 'framer-motion';

interface OrderSuccessProps {
  total: number;
  onTrack: () => void;
  onContinue: () => void;
}

export default function OrderSuccess({ total, onTrack, onContinue }: OrderSuccessProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center p-6 bg-white"
    >
      <div className="mb-8">
        <CheckCircle2 size={100} className="text-red-500 fill-white" />
      </div>

      <div className="text-center mb-10">
        <h2 className="text-3xl font-black mb-3" style={{ color: COLORS.text }}>Order Confirmed!</h2>
        <p className="text-slate-500 text-sm px-6">
          Your order has been placed successfully.<br />
          You will receive a confirmation message shortly.
        </p>
      </div>

      <div className="w-full max-w-sm bg-slate-50 rounded-[32px] p-6 mb-10 space-y-4">
         <div className="flex justify-between items-center">
            <span className="text-sm font-bold text-slate-400">Order Number</span>
            <span className="text-sm font-black" style={{ color: COLORS.text }}>PSL12345678</span>
         </div>
         <div className="flex justify-between items-center">
            <span className="text-sm font-bold text-slate-400">Total Amount</span>
            <span className="text-sm font-black" style={{ color: COLORS.text }}>K{total.toLocaleString()}</span>
         </div>
         <div className="flex justify-between items-center">
            <span className="text-sm font-bold text-slate-400">Estimated Delivery</span>
            <span className="text-sm font-black" style={{ color: COLORS.text }}>2–5 Days</span>
         </div>
      </div>

      <div className="w-full max-w-xs space-y-4">
        <button 
          onClick={onTrack}
          className="w-full h-14 rounded-2xl text-white font-bold text-base flex items-center justify-center active:scale-[0.98] transition-transform shadow-lg shadow-red-500/20"
          style={{ backgroundColor: COLORS.primary }}
        >
          Track Order
        </button>
        <button 
          onClick={onContinue}
          className="w-full h-14 rounded-2xl bg-white border-2 border-slate-100 text-slate-800 font-bold text-base flex items-center justify-center active:scale-[0.98] transition-transform"
        >
          Continue Shopping
        </button>
      </div>
    </motion.div>
  );
}
