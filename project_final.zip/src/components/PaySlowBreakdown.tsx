import { useState, useMemo } from 'react';
import { CreditCard, Calendar } from 'lucide-react';
import { COLORS } from '../theme/constants';

interface PaySlowBreakdownProps {
  price: number;
  inline?: boolean;
}

export default function PaySlowBreakdown({ price, inline = true }: PaySlowBreakdownProps) {
  const [depositPercent, setDepositPercent] = useState(25);
  const installmentCount = 4;

  const depositAmount = useMemo(() => (price * depositPercent) / 100, [price, depositPercent]);
  const remainingBalance = useMemo(() => price - depositAmount, [price, depositAmount]);
  const installmentAmount = useMemo(() => remainingBalance / (installmentCount - 1), [remainingBalance, installmentCount]);

  const schedule = useMemo(() => {
    const dates = ['Today', 'Next Month', 'In 2 Months', 'In 3 Months'];
    return dates.map((date, index) => ({
      label: index === 0 ? 'Deposit' : `Instalment ${index}`,
      subLabel: date,
      amount: index === 0 ? depositAmount : installmentAmount,
      isDeposit: index === 0
    }));
  }, [depositAmount, installmentAmount]);

  return (
    <div className={`space-y-6 ${inline ? '' : 'px-6 pb-6'}`}>
      {/* Calculator Header & Slider */}
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-base font-bold" style={{ color: COLORS.text }}>{depositPercent}% Deposit</span>
          <span className="text-xl font-black" style={{ color: COLORS.primary }}>K{depositAmount.toLocaleString()}</span>
        </div>
        
        <input 
          type="range" 
          min="25" 
          max="75" 
          step="5"
          value={depositPercent}
          onChange={(e) => setDepositPercent(Number(e.target.value))}
          className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-red-500"
          style={{ accentColor: COLORS.primary }}
        />
        <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase">
          <span>MIN 25%</span>
          <span>MAX 75%</span>
        </div>
      </div>

      {/* Summary Boxes */}
      <div className="grid grid-cols-2 gap-4">
         <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Balance</p>
            <p className="text-lg font-black" style={{ color: COLORS.text }}>K{remainingBalance.toLocaleString()}</p>
         </div>
         <div className="bg-red-50 rounded-2xl p-4 border border-red-100">
            <p className="text-[10px] font-bold text-red-400 uppercase tracking-widest mb-1">Instalment</p>
            <p className="text-lg font-black" style={{ color: COLORS.primary }}>K{Math.ceil(installmentAmount).toLocaleString()}</p>
         </div>
      </div>

      {/* Payment Schedule List */}
      <div className="space-y-4 pt-4">
        <h3 className="text-sm font-bold" style={{ color: COLORS.text }}>Payment Schedule</h3>
        <div className="space-y-4">
          {schedule.map((item, idx) => (
            <div key={idx} className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-400">
                {item.isDeposit ? <CreditCard size={20} /> : <Calendar size={20} />}
              </div>
              <div className="flex-1">
                <p className="text-sm font-bold" style={{ color: COLORS.text }}>{item.label}</p>
                <p className="text-xs text-slate-400">{item.subLabel}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-black" style={{ color: COLORS.text }}>K{Math.ceil(item.amount).toLocaleString()}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
