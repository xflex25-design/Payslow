import { X, Info } from 'lucide-react';
import { COLORS } from '../theme/constants';
import { motion, AnimatePresence } from 'framer-motion';
import PaySlowBreakdown from './PaySlowBreakdown';

interface InstallmentCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
  totalPrice: number;
  productName: string;
}

export default function InstallmentCalculator({ isOpen, onClose, totalPrice, productName }: InstallmentCalculatorProps) {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-end justify-center px-4">
        {/* Backdrop */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        />
        
        {/* Bottom Sheet */}
        <motion.div 
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-lg bg-white rounded-t-[32px] overflow-hidden shadow-2xl"
          style={{ maxHeight: '90vh' }}
        >
          {/* Drag handle affordance */}
          <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto my-3" />
          
          <div className="px-6 pb-8 overflow-y-auto no-scrollbar" style={{ maxHeight: 'calc(90vh - 40px)' }}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold" style={{ color: COLORS.text }}>Pay Slowly with PaySlow</h2>
              <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <X size={20} />
              </button>
            </div>

            <div className="bg-slate-50 rounded-2xl p-4 mb-6 flex items-start gap-3 border border-slate-100">
              <Info size={18} className="text-blue-500 shrink-0 mt-0.5" />
              <p className="text-xs text-slate-600 leading-relaxed">
                Estimate your monthly payments for <strong>{productName}</strong>. Adjust your deposit to lower your installments.
              </p>
            </div>

            {/* PaySlow Breakdown Component */}
            <PaySlowBreakdown price={totalPrice} inline={false} />

            {/* CTA */}
            <button 
              onClick={onClose}
              className="w-full h-14 rounded-2xl text-white font-bold text-base mt-8 active:scale-[0.98] transition-transform shadow-lg"
              style={{ backgroundColor: COLORS.primary }}
            >
              Apply for PaySlow Plan
            </button>
            <p className="text-center text-[11px] text-slate-400 mt-4">
              * Total payable: K{totalPrice.toLocaleString()}. Terms and conditions apply.
            </p>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
