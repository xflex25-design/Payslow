import * as LucideIcons from 'lucide-react';
import { COLORS } from '../theme/constants';

interface CategoryCardProps {
  name: string;
  iconName: string;
  isSelected?: boolean;
  onClick?: () => void;
}

export default function CategoryCard({ name, iconName, isSelected, onClick }: CategoryCardProps) {
  // @ts-ignore - Dynamic icon lookup
  const Icon = LucideIcons[iconName] || LucideIcons.Package;
  
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center justify-center p-4 rounded-2xl bg-white shadow-sm border border-slate-50 active:scale-95 transition-all w-full`}
    >
      <div className="mb-2">
        <Icon size={24} style={{ color: COLORS.primary }} />
      </div>
      <span className="text-[11px] font-bold" style={{ color: COLORS.text }}>{name}</span>
    </button>
  );
}
