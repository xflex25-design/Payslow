import { ArrowLeft, MapPin, ChevronRight, Truck, Wallet, Check } from 'lucide-react';
import { COLORS } from '../theme/constants';
import { motion } from 'framer-motion';

interface CheckoutScreenProps {
  total: number;
  onBack: () => void;
  onConfirm: () => void;
}

export default function CheckoutScreen({ total, onBack, onConfirm }: CheckoutScreenProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="fixed inset-0 z-[80] flex flex-col"
      style={{ backgroundColor: COLORS.background }}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-6 h-[70px] bg-white border-b border-slate-100">
        <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-slate-50 transition-colors">
          <ArrowLeft size={24} style={{ color: COLORS.text }} />
        </button>
        <span className="font-bold text-lg" style={{ color: COLORS.text }}>Checkout</span>
        <div className="w-10" /> {/* Spacer */}
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar p-6 space-y-6 pb-32">
        {/* Delivery Address */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Delivery Address</h3>
          <div className="bg-white rounded-2xl p-4 flex items-center gap-4 shadow-sm border border-slate-50">
             <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400">
                <MapPin size={24} />
             </div>
             <div className="flex-1">
                <p className="text-sm font-bold" style={{ color: COLORS.text }}>123 Kaunda Avenue</p>
                <p className="text-xs text-slate-500">Lusaka, Zambia</p>
             </div>
             <ChevronRight size={20} className="text-slate-300" />
          </div>
        </div>

        {/* Delivery Method */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Delivery Method</h3>
          <div className="bg-white rounded-2xl p-4 flex items-center gap-4 shadow-sm border border-slate-50">
             <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center overflow-hidden">
                <img 
                  src="/assets/aistudio/IMG_355fcdf4-425f-4dc6-b9df-13a7eb52ddd2_dbfa6cd7.png" 
                  alt="Delivery"
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
             </div>
             <div className="flex-1">
                <p className="text-sm font-bold" style={{ color: COLORS.text }}>Standard Delivery</p>
                <p className="text-xs text-slate-500">K25 · 2–5 Days</p>
             </div>
             <ChevronRight size={20} className="text-slate-300" />
          </div>
        </div>

        {/* Payment Method */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Payment Method</h3>
          <div className="space-y-3">
            {/* Pay Slow */}
            <div className="bg-white rounded-2xl p-4 flex items-center gap-4 shadow-sm border-2 border-red-100">
               <div className="w-5 h-5 rounded-full border-2 border-red-500 flex items-center justify-center">
                  <div className="w-2.5 h-2.5 bg-red-500 rounded-full" />
               </div>
               <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-black" style={{ color: COLORS.text }}>Pay Slow (Instalments)</p>
                    <span className="bg-red-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded uppercase">Popular</span>
                  </div>
                  <p className="text-[10px] text-slate-500">Pay a small deposit and in instalments</p>
               </div>
            </div>

            {/* Mobile Money */}
            <div className="bg-white rounded-2xl p-4 flex items-center gap-4 shadow-sm border border-slate-50">
               <div className="w-5 h-5 rounded-full border border-slate-200" />
               <div className="flex-1">
                  <p className="text-sm font-bold" style={{ color: COLORS.secondaryText }}>Mobile Money (MTN, Airtel, Zamtel)</p>
                  <div className="flex gap-2 mt-2">
                     <img 
                        src="/assets/aistudio/mtn-logo_4a74e1b2.png" 
                        alt="MTN" 
                        className="h-5 w-auto object-contain rounded-sm"
                        referrerPolicy="no-referrer"
                     />
                     <img 
                        src="/assets/aistudio/IMG_67974b16-294a-43a0-80f6-73f504675b27_a34625cb.png" 
                        alt="Airtel" 
                        className="h-5 w-auto object-contain rounded-sm"
                        referrerPolicy="no-referrer"
                     />
                     <img 
                        src="/assets/aistudio/IMG_d626c724-43a0-4510-a28d-3ef0ffc4e2d9_19320552.png" 
                        alt="Zamtel" 
                        className="h-5 w-auto object-contain rounded-sm"
                        referrerPolicy="no-referrer"
                     />
                  </div>
               </div>
            </div>

            {/* Card Payment */}
            <div className="bg-white rounded-2xl p-4 flex items-center gap-4 shadow-sm border border-slate-50">
               <div className="w-5 h-5 rounded-full border border-slate-200" />
               <div className="flex-1 flex items-center gap-3">
                  <div className="w-10 h-10 bg-slate-50 rounded-lg flex items-center justify-center text-slate-400">
                    <Wallet size={20} />
                  </div>
                  <p className="text-sm font-bold" style={{ color: COLORS.secondaryText }}>Card Payment</p>
               </div>
            </div>
          </div>
        </div>

        {/* Totals */}
        <div className="pt-4 space-y-2">
           <div className="flex justify-between text-sm font-bold text-slate-400">
              <span>Subtotal</span>
              <span style={{ color: COLORS.text }}>K{(total - 25).toLocaleString()}</span>
           </div>
           <div className="flex justify-between text-sm font-bold text-slate-400">
              <span>Delivery Fee</span>
              <span style={{ color: COLORS.text }}>K25</span>
           </div>
           <div className="pt-3 flex justify-between items-center">
              <span className="text-lg font-black" style={{ color: COLORS.text }}>Total</span>
              <span className="text-2xl font-black" style={{ color: COLORS.primary }}>K{total.toLocaleString()}</span>
           </div>
        </div>
      </div>

      {/* Confirm Button */}
      <div className="fixed bottom-0 left-0 right-0 p-6 bg-white border-t border-slate-100">
        <button 
          onClick={onConfirm}
          className="w-full h-14 rounded-2xl text-white font-bold text-base flex items-center justify-center active:scale-[0.98] transition-transform shadow-lg shadow-red-500/20"
          style={{ backgroundColor: COLORS.primary }}
        >
          Confirm Order
        </button>
      </div>
    </motion.div>
  );
}
