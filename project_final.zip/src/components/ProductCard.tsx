import { Heart } from 'lucide-react';
import { COLORS } from '../theme/constants';
import { Product } from '../data/mockData';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onCalculatorOpen: (product: Product) => void;
  onProductClick: (product: Product) => void;
}

export default function ProductCard({ 
  product, 
  isWishlisted,
  onToggleWishlist,
  onCalculatorOpen, 
  onProductClick 
}: ProductCardProps) {
  return (
    <div 
      onClick={() => onProductClick(product)}
      className="bg-white rounded-3xl p-3 shadow-sm border border-slate-50 flex flex-col relative group cursor-pointer"
    >
      {product.badge && (
        <div 
          className="absolute top-3 right-3 z-10 px-2 py-1 rounded-lg text-[10px] font-bold text-white shadow-sm"
          style={{ backgroundColor: COLORS.primary }}
        >
          {product.badge}
        </div>
      )}
      
      <div className="aspect-square rounded-2xl bg-slate-50 mb-3 overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
      </div>
      
      <div className="px-1">
        <h3 className="font-bold text-sm mb-0.5 truncate" style={{ color: COLORS.text }}>
          {product.name}
        </h3>
        <p className="text-[11px] mb-2 truncate" style={{ color: COLORS.secondaryText }}>
          {product.description}
        </p>
        
        <div className="flex items-center justify-between mb-2">
          <span className="font-bold text-sm" style={{ color: COLORS.primary }}>
            K{product.price.toLocaleString()}
          </span>
          
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onToggleWishlist(product);
            }}
            className="p-1 active:scale-125 transition-transform"
          >
            <Heart 
              size={18} 
              fill={isWishlisted ? COLORS.primary : 'transparent'} 
              style={{ color: COLORS.primary }} 
            />
          </button>
        </div>

        {/* Installment Badge */}
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onCalculatorOpen(product);
          }}
          className="flex flex-col items-start px-2.5 py-1.5 rounded-lg active:scale-[0.98] transition-transform text-left"
          style={{ backgroundColor: COLORS.accentPink }}
        >
          <span className="text-[9px] font-bold uppercase tracking-wider mb-0.5" style={{ color: COLORS.primary }}>
            From K{Math.ceil(product.price / 4).toLocaleString()} × 4 payments
          </span>
        </button>
      </div>
    </div>
  );
}
