import { Search, X } from 'lucide-react';
import { COLORS } from '../theme/constants';

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
}

export default function SearchBar({ value, onChange }: SearchBarProps) {
  return (
    <div className="px-6 pt-4 pb-2">
      <div className="relative flex items-center group">
        <div className="absolute left-4">
          <Search size={18} style={{ color: COLORS.primary }} />
        </div>
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Search for anything..."
          className="w-full h-12 pl-11 pr-11 bg-white rounded-2xl text-[13px] font-medium shadow-sm border border-slate-100 focus:outline-none focus:border-red-200 transition-all placeholder:text-slate-400"
          style={{ 
            color: COLORS.text,
          }}
        />
        {value.length > 0 && (
          <button 
            onClick={() => onChange('')}
            className="absolute right-4 p-1 hover:bg-slate-50 rounded-full transition-colors"
          >
            <X size={16} className="text-slate-400" />
          </button>
        )}
      </div>
    </div>
  );
}
