import { CheckCircle2, ShoppingCart } from 'lucide-react';
import { COLORS } from '../theme/constants';
import { motion } from 'framer-motion';

interface AddToCartSuccessProps {
  onViewCart: () => void;
  onContinue: () => void;
}

export default function AddToCartSuccess({ onViewCart, onContinue }: AddToCartSuccessProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center p-6 bg-white"
    >
      <div className="relative mb-8">
        <div className="w-48 h-48 bg-slate-50 rounded-full flex items-center justify-center">
           {/* Illustration placeholder - simple cart in circle */}
           <div className="relative">
              <div className="w-32 h-32 bg-white rounded-2xl shadow-sm flex items-center justify-center border border-slate-50">
                <ShoppingCart size={64} className="text-slate-200" />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-white rounded-full p-1 shadow-md">
                <CheckCircle2 size={48} className="text-emerald-500 fill-white" />
              </div>
           </div>
        </div>
      </div>

      <div className="text-center mb-10">
        <h2 className="text-2xl font-black mb-2" style={{ color: COLORS.text }}>Added to Cart!</h2>
        <p className="text-slate-500 text-sm">Your item has been added<br />to your cart successfully.</p>
      </div>

      <div className="w-full max-w-xs space-y-4">
        <button 
          onClick={onViewCart}
          className="w-full h-14 rounded-2xl text-white font-bold text-base flex items-center justify-center active:scale-[0.98] transition-transform shadow-lg shadow-red-500/20"
          style={{ backgroundColor: COLORS.primary }}
        >
          View Cart
        </button>
        <button 
          onClick={onContinue}
          className="w-full h-14 rounded-2xl bg-white border-2 border-slate-100 text-slate-800 font-bold text-base flex items-center justify-center active:scale-[0.98] transition-transform"
        >
          Continue Shopping
        </button>
      </div>
    </motion.div>
  );
}
