import { ArrowLeft, Minus, Plus, Bookmark, Trash2, ShoppingCart } from 'lucide-react';
import { COLORS } from '../theme/constants';
import { motion } from 'framer-motion';
import { CartItem } from '../screens/HomeScreen';

interface CartScreenProps {
  items: CartItem[];
  onBack: () => void;
  onCheckout: () => void;
  onContinue: () => void;
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemove: (productId: string) => void;
}

export default function CartScreen({ 
  items, 
  onBack, 
  onCheckout, 
  onContinue,
  onUpdateQuantity,
  onRemove
}: CartScreenProps) {
  const subtotal = items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const deliveryFee = subtotal > 0 ? 25 : 0;
  const total = subtotal + deliveryFee;

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="fixed inset-0 z-[70] flex flex-col"
      style={{ backgroundColor: COLORS.background }}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-6 h-[70px] bg-white border-b border-slate-100">
        <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-slate-50 transition-colors">
          <ArrowLeft size={24} style={{ color: COLORS.text }} />
        </button>
        <span className="font-bold text-lg" style={{ color: COLORS.text }}>My Cart</span>
        <div className="relative">
          <ShoppingCart size={24} style={{ color: COLORS.text }} />
          <div className="absolute -top-2 -right-2 bg-red-600 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center border-2 border-white">
            {items.reduce((sum, item) => sum + item.quantity, 0)}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar pb-32">
        {/* Banner */}
        <div className="px-6 py-4 flex items-center gap-4">
           <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center">
              <ShoppingCart size={32} className="text-slate-300" />
           </div>
           <div>
              <h3 className="font-black text-lg" style={{ color: COLORS.text }}>Your items are waiting for you!</h3>
              <p className="text-xs text-slate-500">Review your cart and proceed to checkout.</p>
           </div>
        </div>

        {/* Cart Items */}
        <div className="px-6 space-y-4">
          {items.map((item) => (
            <div key={item.product.id} className="bg-white rounded-[24px] p-4 shadow-sm border border-slate-50 flex gap-4">
              <div className="w-24 h-24 rounded-2xl bg-slate-50 overflow-hidden shrink-0">
                <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 flex flex-col justify-between py-1">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-sm" style={{ color: COLORS.text }}>{item.product.name}</h4>
                    <p className="text-xs font-black mt-1" style={{ color: COLORS.primary }}>K{item.product.price.toLocaleString()}</p>
                  </div>
                  <button 
                    onClick={() => onRemove(item.product.id)}
                    className="text-slate-300 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
                
                <div className="flex items-center justify-between">
                   <div className="flex items-center gap-4 bg-slate-50 rounded-lg p-1">
                      <button 
                        onClick={() => onUpdateQuantity(item.product.id, -1)}
                        className="w-7 h-7 rounded-md bg-white shadow-sm flex items-center justify-center active:scale-90 transition-transform"
                      >
                        <Minus size={14} className="text-slate-400" />
                      </button>
                      <span className="text-sm font-bold">{item.quantity}</span>
                      <button 
                        onClick={() => onUpdateQuantity(item.product.id, 1)}
                        className="w-7 h-7 rounded-md bg-white shadow-sm flex items-center justify-center active:scale-90 transition-transform"
                      >
                        <Plus size={14} className="text-slate-400" />
                      </button>
                   </div>
                   <div className="flex items-center gap-3">
                      <button className="flex items-center gap-1 text-[11px] font-bold text-slate-400">
                        <Bookmark size={14} />
                        Save
                      </button>
                      <button 
                        onClick={() => onRemove(item.product.id)}
                        className="flex items-center gap-1 text-[11px] font-bold text-slate-400"
                      >
                        <Trash2 size={14} />
                        Remove
                      </button>
                   </div>
                </div>
              </div>
            </div>
          ))}
          
          {items.length === 0 && (
            <div className="py-20 text-center">
               <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <ShoppingCart size={32} className="text-slate-200" />
               </div>
               <p className="text-slate-400 font-bold">Your cart is empty</p>
               <button 
                 onClick={onContinue}
                 className="mt-4 px-6 py-2 bg-slate-100 rounded-full text-xs font-bold text-slate-500"
               >
                 Start Shopping
               </button>
            </div>
          )}
        </div>

        {/* Summary Section */}
        {items.length > 0 && (
          <div className="px-6 mt-8 space-y-3">
             <div className="flex justify-between text-sm font-bold text-slate-500">
                <span>Subtotal ({items.reduce((sum, i) => sum + i.quantity, 0)} items)</span>
                <span style={{ color: COLORS.text }}>K{subtotal.toLocaleString()}</span>
             </div>
             <div className="flex justify-between text-sm font-bold text-slate-500">
                <span>Delivery Fee</span>
                <span style={{ color: COLORS.text }}>K{deliveryFee.toLocaleString()}</span>
             </div>
             <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
                <span className="text-base font-black" style={{ color: COLORS.text }}>Total</span>
                <span className="text-xl font-black" style={{ color: COLORS.primary }}>K{total.toLocaleString()}</span>
             </div>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="fixed bottom-0 left-0 right-0 p-6 bg-white border-t border-slate-100 space-y-4">
        <div className="flex flex-col items-center gap-3">
           <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Supported Payments</p>
           <div className="flex items-center gap-4 bg-slate-50 px-5 py-2 rounded-2xl border border-slate-100/50">
              <img src="/assets/aistudio/mtn-logo_4a74e1b2.png" alt="MTN" className="h-5 w-auto object-contain" referrerPolicy="no-referrer" />
              <img src="/assets/aistudio/IMG_67974b16-294a-43a0-80f6-73f504675b27_a34625cb.png" alt="Airtel" className="h-5 w-auto object-contain" referrerPolicy="no-referrer" />
              <img src="/assets/aistudio/IMG_d626c724-43a0-4510-a28d-3ef0ffc4e2d9_19320552.png" alt="Zamtel" className="h-5 w-auto object-contain" referrerPolicy="no-referrer" />
           </div>
        </div>
        <button 
          onClick={onCheckout}
          disabled={items.length === 0}
          className={`w-full h-14 rounded-2xl text-white font-bold text-base flex items-center justify-center gap-2 active:scale-[0.98] transition-transform shadow-lg ${items.length === 0 ? 'bg-slate-300 shadow-none' : 'shadow-red-500/20'}`}
          style={{ backgroundColor: items.length > 0 ? COLORS.primary : undefined }}
        >
          Proceed to Checkout <Plus size={20} className="rotate-45" />
        </button>
        <button 
          onClick={onContinue}
          className="w-full h-14 rounded-2xl bg-white border-2 border-slate-100 text-slate-800 font-bold text-base flex items-center justify-center active:scale-[0.98] transition-transform"
        >
          Continue Shopping
        </button>
      </div>
    </motion.div>
  );
}
