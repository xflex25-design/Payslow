import { Bell, SlidersHorizontal } from 'lucide-react';
import { COLORS } from '../theme/constants';

/**
 * Header component for PAY SLOW.
 * Features the brand logo on the left and utility icons (filter, notification) on the right.
 * Styled with a solid primary red background as per the Zambian market design direction.
 */
export default function Header() {
  return (
    <header 
      className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 h-[80px] shadow-sm"
      style={{ backgroundColor: COLORS.navBackground }}
    >
      {/* Brand Logo Section */}
      <div className="flex items-center">
        <img 
          src="/assets/aistudio/file_00000000791c81f49cb8b8fd37125592_39b4d170.png" 
          alt="PAY SLOW Logo"
          className="h-[45px] w-auto object-contain"
          referrerPolicy="no-referrer"
        />
      </div>
      
      {/* Action Icons Section */}
      <div className="flex items-center gap-3">
        {/* Filter Button - Subtle outlined rounded button */}
        <button 
          aria-label="Filter"
          className="w-11 h-11 rounded-xl border border-white/30 flex items-center justify-center text-white active:bg-white/10 transition-colors cursor-pointer"
        >
          <SlidersHorizontal size={20} />
        </button>
        
        {/* Notification Bell with Badge */}
        <div className="relative">
          <button 
            aria-label="Notifications"
            className="w-11 h-11 flex items-center justify-center text-white active:scale-95 transition-transform cursor-pointer"
          >
            <Bell size={26} />
          </button>
          
          {/* Notification Badge - Showing 42 as specified */}
          <div 
            className="absolute top-1.5 right-1.5 bg-white rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1 shadow-sm"
            style={{ border: `1px solid ${COLORS.primary}20` }}
          >
            <span 
              className="text-[10px] font-black leading-none" 
              style={{ color: COLORS.primary }}
            >
              42
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
