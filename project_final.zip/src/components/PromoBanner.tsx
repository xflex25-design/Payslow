import { MoveRight } from 'lucide-react';
import { COLORS } from '../theme/constants';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const BANNERS = [
  {
    id: 1,
    title: 'Payslow',
    subtitle: 'Shop Smart. Pay Slow.',
    buttonText: 'Shop Now',
    image: '/src/assets/images/promo_shopping_cart_1793437531582.jpg',
    bgColor: COLORS.primary,
  },
  {
    id: 2,
    title: 'Latest iPhone',
    subtitle: 'Spread the cost monthly.',
    buttonText: 'View Deals',
    image: '/src/assets/images/product_iphone_16_pro_1793437531705.jpg',
    bgColor: '#171717', // Black for premium iPhone
  },
  {
    id: 3,
    title: 'Smart Home',
    subtitle: 'Upgrade your living space.',
    buttonText: 'Browse',
    image: '/src/assets/images/product_smart_tv_1793437532274.jpg',
    bgColor: '#2E5BFF', // Blue for tech
  }
];

export default function PromoBanner() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % BANNERS.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const banner = BANNERS[currentIndex];

  return (
    <div className="px-6 py-4">
      <div className="relative h-[190px] rounded-[32px] overflow-hidden shadow-lg group">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1 }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            onDragEnd={(_, info) => {
              if (info.offset.x > 100) {
                setCurrentIndex((prev) => (prev - 1 + BANNERS.length) % BANNERS.length);
              } else if (info.offset.x < -100) {
                setCurrentIndex((prev) => (prev + 1) % BANNERS.length);
              }
            }}
            className="absolute inset-0 flex items-center px-8 cursor-grab active:cursor-grabbing"
            style={{ backgroundColor: banner.bgColor }}
          >
            <div className="flex-1 z-10 select-none">
              <h2 className="text-white text-4xl font-bold mb-1 tracking-tight">{banner.title}</h2>
              <p className="text-white/90 text-sm font-medium mb-6">{banner.subtitle}</p>
              
              <button 
                className="bg-white px-6 py-2.5 rounded-xl flex items-center gap-2 group active:scale-95 transition-transform shadow-sm"
                onClick={(e) => e.stopPropagation()}
              >
                <span className="font-bold text-sm" style={{ color: banner.bgColor === COLORS.primary ? COLORS.primary : '#171717' }}>
                  {banner.buttonText}
                </span>
                <MoveRight size={16} style={{ color: banner.bgColor === COLORS.primary ? COLORS.primary : '#171717' }} />
              </button>
            </div>
            
            <div className="absolute right-0 top-0 bottom-0 w-1/2 overflow-hidden pointer-events-none">
              <motion.img 
                key={banner.image}
                initial={{ x: 30, opacity: 0 }}
                animate={{ x: 0, opacity: 0.9 }}
                transition={{ duration: 0.8, delay: 0.1 }}
                src={banner.image} 
                alt="Promo"
                className="w-full h-full object-cover mix-blend-multiply"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Pagination Dots */}
        <div className="absolute bottom-4 left-8 flex items-center gap-2 z-20">
          {BANNERS.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                currentIndex === idx ? 'w-6 bg-white' : 'w-1.5 bg-white/40'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
