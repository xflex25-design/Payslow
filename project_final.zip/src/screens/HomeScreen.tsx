import { useState, useMemo } from 'react';
import Header from '../components/Header';
import SearchBar from '../components/SearchBar';
import PromoBanner from '../components/PromoBanner';
import CategoryCard from '../components/CategoryCard';
import ProductCard from '../components/ProductCard';
import BottomNavigation from '../components/BottomNavigation';
import { CATEGORIES, PRODUCTS } from '../data/mockData';
import { COLORS } from '../theme/constants';
import { ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import HistoryScreen from './HistoryScreen';
import WishlistScreen from './WishlistScreen';
import InstallmentCalculator from '../components/InstallmentCalculator';
import ProductDetails from '../components/ProductDetails';
import CartScreen from '../components/CartScreen';
import CheckoutScreen from '../components/CheckoutScreen';
import AddToCartSuccess from '../components/AddToCartSuccess';
import OrderSuccess from '../components/OrderSuccess';
import { Product } from '../data/mockData';
import AccountScreen from './AccountScreen';

export interface CartItem {
  product: Product;
  quantity: number;
}

const TABS = ['All products', 'Best Deals', 'Top Rated', 'New Arrivals'];

export default function HomeScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState(TABS[0]);
  const [navTab, setNavTab] = useState<'shop' | 'cart' | 'history' | 'wishlist' | 'account'>('shop');
  const [selectedProductForCalc, setSelectedProductForCalc] = useState<Product | null>(null);
  const [viewingProduct, setViewingProduct] = useState<Product | null>(null);
  const [isCalcOpen, setIsCalcOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [showCartSuccess, setShowCartSuccess] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [showOrderSuccess, setShowOrderSuccess] = useState(false);
  const [wishlistProductIds, setWishlistProductIds] = useState<Set<string>>(new Set());

  const openCalculator = (product: Product) => {
    setSelectedProductForCalc(product);
    setIsCalcOpen(true);
  };

  const addToCart = (product: Product) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.product.id === product.id 
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setViewingProduct(null);
    setShowCartSuccess(true);
  };

  const updateCartQuantity = (productId: string, delta: number) => {
    setCartItems(prev => {
      return prev.map(item => {
        if (item.product.id === productId) {
          const newQty = Math.max(0, item.quantity + delta);
          return { ...item, quantity: newQty };
        }
        return item;
      }).filter(item => item.quantity > 0);
    });
  };

  const removeFromCart = (productId: string) => {
    setCartItems(prev => prev.filter(item => item.product.id !== productId));
  };

  const toggleWishlist = (product: Product) => {
    setWishlistProductIds(prev => {
      const next = new Set(prev);
      if (next.has(product.id)) {
        next.delete(product.id);
      } else {
        next.add(product.id);
      }
      return next;
    });
  };

  const wishlistItems = useMemo(() => {
    return PRODUCTS.filter(p => wishlistProductIds.has(p.id));
  }, [wishlistProductIds]);

  const handleCheckout = () => {
    setShowCheckout(true);
  };

  const handleConfirmOrder = () => {
    setShowCheckout(false);
    setShowOrderSuccess(true);
    setCartItems([]); // Clear cart after order
  };

  const cartTotal = useMemo(() => {
    const subtotal = cartItems.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
    return subtotal > 0 ? subtotal + 25 : 0;
  }, [cartItems]);

  const filteredProducts = useMemo(() => {
    let result = PRODUCTS;

    // Search filter
    if (searchQuery) {
      result = result.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Category filter
    if (activeCategory) {
      // In a real app, products would have a categoryId. 
      // For this mock, we'll map them or just filter by some logic.
      // Let's assume some products belong to categories.
      if (activeCategory === 'phones') result = result.filter(p => p.name.toLowerCase().includes('iphone') || p.name.toLowerCase().includes('galaxy'));
      if (activeCategory === 'electronics') result = result.filter(p => p.name.toLowerCase().includes('tv') || p.name.toLowerCase().includes('console') || p.name.toLowerCase().includes('maker'));
      if (activeCategory === 'fashion') result = result.filter(p => p.name.toLowerCase().includes('shoes') || p.name.toLowerCase().includes('backpack'));
      if (activeCategory === 'home') result = result.filter(p => p.name.toLowerCase().includes('tv') || p.name.toLowerCase().includes('maker'));
    }

    // Tab filter
    if (activeTab === 'Best Deals') {
      result = result.filter(p => p.badge === 'Best Deal');
    } else if (activeTab === 'Top Rated') {
      result = result.filter(p => p.rating >= 4.7);
    } else if (activeTab === 'New Arrivals') {
      result = result.filter(p => p.badge === 'New' || p.badge === 'New Arrivals');
    }

    return result;
  }, [searchQuery, activeCategory, activeTab]);

  return (
    <div 
      className="min-h-screen pb-[100px]"
      style={{ backgroundColor: COLORS.background }}
    >
      <Header />
      
      {/* Spacer for fixed header */}
      <div className="h-[80px]" />
      
      <main className="max-w-2xl mx-auto">
        {navTab === 'shop' && (
          <>
            <div 
              className="sticky top-[80px] z-40"
              style={{ backgroundColor: COLORS.background }}
            >
              <SearchBar value={searchQuery} onChange={setSearchQuery} />
            </div>
            
            <PromoBanner />
            
            {/* Category Shortcuts */}
            <section className="px-6 py-4">
              <div className="grid grid-cols-4 gap-4">
                {CATEGORIES.map(category => (
                  <CategoryCard 
                    key={category.id}
                    name={category.name}
                    iconName={category.iconName}
                    isSelected={activeCategory === category.id}
                    onClick={() => setActiveCategory(category.id === activeCategory ? null : category.id)}
                  />
                ))}
              </div>
            </section>
            
            {/* Featured Sections */}
            <section className="px-6 py-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-6 bg-red-600 rounded-full" style={{ backgroundColor: COLORS.primary }} />
                  <h2 className="text-lg font-bold" style={{ color: COLORS.text }}>Featured sections</h2>
                </div>
                <button className="flex items-center gap-1 text-[13px] font-bold" style={{ color: COLORS.primary }}>
                  See all <ChevronRight size={14} />
                </button>
              </div>
              
              <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
                {TABS.map(tab => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-5 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all`}
                    style={{ 
                      backgroundColor: activeTab === tab ? COLORS.primary : '#F0F0F0',
                      color: activeTab === tab ? '#FFFFFF' : COLORS.text
                    }}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </section>
            
            {/* Product Grid */}
            <section className="px-6 py-2">
              <div className="grid grid-cols-2 gap-4">
                <AnimatePresence mode='popLayout'>
                  {filteredProducts.map(product => (
                    <motion.div
                      key={product.id}
                      layout
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ duration: 0.2 }}
                    >
                      <ProductCard 
                        product={product} 
                        isWishlisted={wishlistProductIds.has(product.id)}
                        onToggleWishlist={toggleWishlist}
                        onCalculatorOpen={openCalculator}
                        onProductClick={(p) => setViewingProduct(p)}
                      />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
              
              {filteredProducts.length === 0 && (
                <div className="py-20 text-center">
                  <p className="text-slate-400 font-medium">No products found matching "{searchQuery}"</p>
                </div>
              )}
            </section>
          </>
        )}

        {navTab === 'history' && <HistoryScreen />}
        {navTab === 'wishlist' && (
          <WishlistScreen 
            items={wishlistItems}
            onToggleWishlist={toggleWishlist}
            onProductClick={(p) => setViewingProduct(p)}
            onCalculatorOpen={openCalculator}
          />
        )}

        {navTab === 'cart' && (
          <CartScreen 
            items={cartItems}
            onBack={() => setNavTab('shop')}
            onCheckout={handleCheckout}
            onContinue={() => setNavTab('shop')}
            onUpdateQuantity={updateCartQuantity}
            onRemove={removeFromCart}
          />
        )}

        {navTab === 'account' && (
          <AccountScreen />
        )}
      </main>

      <InstallmentCalculator 
        isOpen={isCalcOpen}
        onClose={() => setIsCalcOpen(false)}
        totalPrice={selectedProductForCalc?.price || 0}
        productName={selectedProductForCalc?.name || ''}
      />

      <AnimatePresence>
        {viewingProduct && (
          <ProductDetails 
            product={viewingProduct} 
            isWishlisted={wishlistProductIds.has(viewingProduct.id)}
            onToggleWishlist={toggleWishlist}
            onBack={() => setViewingProduct(null)} 
            onAddToCart={addToCart}
            onPaySlow={(p) => openCalculator(p)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCartSuccess && (
          <AddToCartSuccess 
            onViewCart={() => {
              setShowCartSuccess(false);
              setNavTab('cart');
            }}
            onContinue={() => setShowCartSuccess(false)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCheckout && (
          <CheckoutScreen 
            total={cartTotal}
            onBack={() => setShowCheckout(false)}
            onConfirm={handleConfirmOrder}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showOrderSuccess && (
          <OrderSuccess 
            total={cartTotal}
            onTrack={() => {
               setShowOrderSuccess(false);
               setNavTab('history');
            }}
            onContinue={() => setShowOrderSuccess(false)}
          />
        )}
      </AnimatePresence>
      
      <BottomNavigation 
        activeTab={navTab} 
        onTabChange={setNavTab} 
      />
    </div>
  );
}
