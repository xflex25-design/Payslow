import { Heart, ChevronRight } from 'lucide-react';
import { COLORS } from '../theme/constants';
import { Product } from '../data/mockData';
import ProductCard from '../components/ProductCard';
import { motion, AnimatePresence } from 'framer-motion';

interface WishlistScreenProps {
  items: Product[];
  onToggleWishlist: (product: Product) => void;
  onProductClick: (product: Product) => void;
  onCalculatorOpen: (product: Product) => void;
}

export default function WishlistScreen({ items, onToggleWishlist, onProductClick, onCalculatorOpen }: WishlistScreenProps) {
  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Header */}
      <div className="px-6 py-4 bg-white border-b border-slate-100 flex items-center justify-between">
        <h2 className="text-xl font-bold" style={{ color: COLORS.text }}>My Wishlist ({items.length})</h2>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar">
        {items.length > 0 ? (
          <div className="p-6 grid grid-cols-2 gap-4">
            <AnimatePresence mode="popLayout">
              {items.map((product) => (
                <motion.div
                  key={product.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.2 }}
                >
                  <ProductCard 
                    product={product}
                    isWishlisted={true}
                    onToggleWishlist={() => onToggleWishlist(product)}
                    onProductClick={onProductClick}
                    onCalculatorOpen={onCalculatorOpen}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        ) : (
          /* Empty State Card */
          <div className="flex-1 flex items-center justify-center px-6 py-20">
            <div className="w-full max-w-sm bg-white rounded-[32px] p-10 shadow-sm border border-slate-50 flex flex-col items-center text-center">
              <div className="mb-6">
                <Heart 
                  size={48} 
                  strokeWidth={1.5}
                  style={{ color: COLORS.primary }} 
                />
              </div>
              
              <h3 className="text-xl font-bold mb-3" style={{ color: COLORS.text }}>Your wishlist is empty</h3>
              <p className="text-[14px] leading-relaxed px-4" style={{ color: COLORS.secondaryText }}>
                Products you like will appear here so you can save them for later.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
