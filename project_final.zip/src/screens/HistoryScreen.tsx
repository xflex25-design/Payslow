import { Search, History as HistoryIcon, Package, Truck, CheckCircle2, ChevronRight } from 'lucide-react';
import { useState, useMemo } from 'react';
import { COLORS } from '../theme/constants';
import { MOCK_ORDERS, Order } from '../data/mockData';
import { motion } from 'framer-motion';

const TABS = ['In Progress', 'Completed', 'Cancelled'];

export default function HistoryScreen() {
  const [activeTab, setActiveTab] = useState(TABS[0]);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredOrders = useMemo(() => {
    return MOCK_ORDERS.filter(order => {
      const matchesSearch = order.id.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          order.items.some(item => item.name.toLowerCase().includes(searchQuery.toLowerCase()));
      
      if (activeTab === 'In Progress') return matchesSearch && (order.status === 'Processing' || order.status === 'Shipped');
      if (activeTab === 'Completed') return matchesSearch && order.status === 'Delivered';
      if (activeTab === 'Cancelled') return matchesSearch && order.status === 'Cancelled';
      return matchesSearch;
    });
  }, [activeTab, searchQuery]);

  const counts = useMemo(() => ({
    'In Progress': MOCK_ORDERS.filter(o => o.status === 'Processing' || o.status === 'Shipped').length,
    'Completed': MOCK_ORDERS.filter(o => o.status === 'Delivered').length,
    'Cancelled': MOCK_ORDERS.filter(o => o.status === 'Cancelled').length,
  }), []);

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Header */}
      <div className="px-6 py-4 bg-white border-b border-slate-100">
        <h2 className="text-xl font-bold" style={{ color: COLORS.text }}>My PaySlow History</h2>
      </div>

      {/* Filter Tabs */}
      <div className="px-6 py-4 bg-white">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          {TABS.map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl border transition-all"
              style={{
                backgroundColor: activeTab === tab ? COLORS.primary : 'transparent',
                borderColor: activeTab === tab ? COLORS.primary : COLORS.border,
                color: activeTab === tab ? '#FFFFFF' : COLORS.text
              }}
            >
              <span className="text-[13px] font-bold">{tab}</span>
              <div 
                className={`min-w-[18px] h-[18px] rounded-full flex items-center justify-center px-1 text-[10px] font-bold`}
                style={{ 
                  backgroundColor: activeTab === tab ? 'rgba(255,255,255,0.2)' : COLORS.border,
                  color: activeTab === tab ? '#FFFFFF' : COLORS.secondaryText
                }}
              >
                {counts[tab as keyof typeof counts]}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Search Bar */}
      <div className="px-6 pb-4 bg-white shadow-sm">
        <div className="relative flex items-center">
          <div className="absolute left-4">
            <Search size={18} className="text-slate-400" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search your purchase history"
            className="w-full h-11 pl-11 pr-4 bg-slate-50 rounded-xl text-sm border border-transparent focus:border-slate-200 focus:outline-none transition-all"
          />
        </div>
      </div>

      {/* Orders List */}
      <div className="flex-1 overflow-y-auto no-scrollbar p-6 space-y-6">
        {filteredOrders.length > 0 ? (
          filteredOrders.map((order) => (
            <OrderCard key={order.id} order={order} />
          ))
        ) : (
          /* Empty State */
          <div className="flex-1 flex flex-col items-center justify-center py-20 text-center">
            <div 
              className="w-20 h-20 rounded-full flex items-center justify-center mb-6 mx-auto"
              style={{ backgroundColor: `${COLORS.primary}10` }}
            >
              <HistoryIcon size={36} style={{ color: COLORS.primary }} />
            </div>
            <h3 className="text-lg font-bold mb-2" style={{ color: COLORS.text }}>No {activeTab.toLowerCase()} yet</h3>
            <p className="text-sm px-10" style={{ color: COLORS.secondaryText }}>
              Your purchases and payment activities for this section will appear here.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function OrderCard({ order }: { order: Order }) {
  const steps = [
    { label: 'Processing', Icon: Package },
    { label: 'Shipped', Icon: Truck },
    { label: 'Delivered', Icon: CheckCircle2 },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-[24px] p-5 shadow-sm border border-slate-50 space-y-5"
    >
      <div className="flex justify-between items-start">
        <div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Order ID: {order.id}</p>
          <h3 className="font-bold text-sm" style={{ color: COLORS.text }}>{order.items.map(i => i.name).join(', ')}</h3>
          <p className="text-xs text-slate-400 mt-0.5">{order.date}</p>
        </div>
        <div className="text-right">
          <p className="text-sm font-black" style={{ color: COLORS.primary }}>K{order.total.toLocaleString()}</p>
          <div className="flex items-center gap-1 mt-1 justify-end">
            <span className="text-[10px] font-bold text-slate-400">View Details</span>
            <ChevronRight size={12} className="text-slate-300" />
          </div>
        </div>
      </div>

      {/* Tracking Progress Bar */}
      {order.status !== 'Cancelled' && (
        <div className="pt-2">
          <div className="relative flex justify-between">
            {/* Progress Line */}
            <div className="absolute top-4 left-0 right-0 h-0.5 bg-slate-100" />
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${((order.trackingStep - 1) / (steps.length - 1)) * 100}%` }}
              className="absolute top-4 left-0 h-0.5"
              style={{ backgroundColor: COLORS.primary }}
            />
            
            {steps.map((step, idx) => {
              const StepIcon = step.Icon;
              const isCompleted = order.trackingStep > idx + 1;
              const isActive = order.trackingStep === idx + 1;
              
              return (
                <div key={idx} className="relative z-10 flex flex-col items-center">
                  <div 
                    className={`w-8 h-8 rounded-full flex items-center justify-center border-4 border-white transition-colors duration-500 shadow-sm`}
                    style={{ 
                      backgroundColor: isCompleted || isActive ? COLORS.primary : '#F8FAFC',
                    }}
                  >
                    <StepIcon size={14} className={isCompleted || isActive ? 'text-white' : 'text-slate-300'} />
                  </div>
                  <p 
                    className={`text-[9px] font-black mt-2 uppercase tracking-tighter ${isActive ? 'text-red-500' : 'text-slate-400'}`}
                    style={{ color: isActive ? COLORS.primary : undefined }}
                  >
                    {step.label}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </motion.div>
  );
}
