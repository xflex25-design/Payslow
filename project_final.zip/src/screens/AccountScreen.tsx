import { User, MapPin, CreditCard, Bell, Shield, LogOut, ChevronRight, Settings, HelpCircle, Heart } from 'lucide-react';
import { COLORS } from '../theme/constants';
import { motion } from 'framer-motion';

export default function AccountScreen() {
  const sections = [
    {
      title: 'Personal Info',
      items: [
        { icon: User, label: 'Profile Details', subLabel: 'Manage your personal information' },
        { icon: MapPin, label: 'Saved Addresses', subLabel: 'Lusaka, Zambia' },
      ]
    },
    {
      title: 'Payments & Activities',
      items: [
        { icon: CreditCard, label: 'Payment Methods', subLabel: 'MTN Mobile Money' },
        { icon: Heart, label: 'Wishlist', subLabel: '12 items saved' },
      ]
    },
    {
      title: 'Preferences',
      items: [
        { icon: Bell, label: 'Notifications', subLabel: 'On' },
        { icon: Shield, label: 'Security & Privacy', subLabel: 'Password, FaceID' },
        { icon: HelpCircle, label: 'Help & Support', subLabel: 'FAQs, Live Chat' },
      ]
    }
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-50">
      {/* Header Profile */}
      <div className="bg-white px-6 pt-8 pb-10 rounded-b-[40px] shadow-sm border-b border-slate-100">
        <div className="flex items-center gap-5">
          <div className="relative">
             <div className="w-20 h-20 rounded-[24px] bg-red-50 flex items-center justify-center border-4 border-white shadow-lg shadow-red-500/10 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=256&h=256&auto=format&fit=crop" 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
             </div>
             <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-white rounded-lg shadow-md flex items-center justify-center border border-slate-50">
                <Settings size={14} className="text-slate-400" />
             </div>
          </div>
          <div>
            <h2 className="text-xl font-black" style={{ color: COLORS.text }}>Banda Chilufya</h2>
            <p className="text-xs font-bold text-slate-400 mt-0.5">banda.chi@example.zm</p>
            <div className="flex items-center gap-2 mt-3">
               <span className="bg-red-50 text-red-600 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">VIP Member</span>
               <span className="bg-slate-50 text-slate-400 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">K5,250 Spent</span>
            </div>
          </div>
        </div>
      </div>

      {/* Menu Sections */}
      <div className="flex-1 overflow-y-auto no-scrollbar p-6 space-y-8 pb-32">
        {sections.map((section, idx) => (
          <div key={idx} className="space-y-4">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest px-1">{section.title}</h3>
            <div className="bg-white rounded-[24px] shadow-sm border border-slate-50 overflow-hidden">
              {section.items.map((item, itemIdx) => (
                <button 
                  key={itemIdx}
                  className={`w-full p-4 flex items-center gap-4 hover:bg-slate-50 transition-colors ${
                    itemIdx !== section.items.length - 1 ? 'border-b border-slate-50' : ''
                  }`}
                >
                  <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-400">
                    <item.icon size={20} />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-bold" style={{ color: COLORS.text }}>{item.label}</p>
                    <p className="text-xs text-slate-400">{item.subLabel}</p>
                  </div>
                  <ChevronRight size={18} className="text-slate-300" />
                </button>
              ))}
            </div>
          </div>
        ))}

        {/* Logout Button */}
        <button className="w-full h-14 rounded-2xl bg-white border-2 border-slate-100 flex items-center justify-center gap-3 active:scale-[0.98] transition-transform shadow-sm">
          <LogOut size={20} className="text-red-500" />
          <span className="font-bold text-slate-800">Log Out</span>
        </button>
        
        <p className="text-center text-[10px] font-bold text-slate-300 uppercase tracking-widest pb-4">
          PaySlow Zambia v1.0.2
        </p>
      </div>
    </div>
  );
}
