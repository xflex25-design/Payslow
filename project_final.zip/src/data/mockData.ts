export interface Review {
  id: string;
  userName: string;
  userAvatar: string;
  rating: number;
  date: string;
  comment: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  badge?: string;
  isFavorite: boolean;
  rating: number;
  reviewCount: number;
  reviews: Review[];
}

export interface Category {
  id: string;
  name: string;
  iconName: string;
}

export const CATEGORIES: Category[] = [
  { id: 'phones', name: 'Phones', iconName: 'Smartphone' },
  { id: 'electronics', name: 'Electronics', iconName: 'Laptop' },
  { id: 'fashion', name: 'Fashion', iconName: 'Shirt' },
  { id: 'home', name: 'Home & Living', iconName: 'Home' },
];

const MOCK_REVIEWS: Review[] = [
  {
    id: 'r1',
    userName: 'Chanda Musonda',
    userAvatar: '/src/assets/images/avatar_user_1_1793448698257.jpg',
    rating: 5,
    date: '2 days ago',
    comment: 'Exceptional quality. The PaySlow plan made it so easy to afford this high-end device. Highly recommended!'
  },
  {
    id: 'r2',
    userName: 'Mutale Kapambwe',
    userAvatar: '/src/assets/images/avatar_user_2_1793448699462.jpg',
    rating: 4,
    date: '1 week ago',
    comment: 'Great product, delivery was on time. The monthly payments are very manageable.'
  },
  {
    id: 'r3',
    userName: 'Bwalya Phiri',
    userAvatar: '/src/assets/images/avatar_user_3_1793448698661.jpg',
    rating: 5,
    date: '3 weeks ago',
    comment: 'The best shopping experience in Zambia so far. Professional and transparent.'
  }
];

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'iPhone 16 Pro',
    description: '128GB • 5G • Latest Model',
    price: 19999,
    image: '/src/assets/images/product_iphone_16_pro_1793437531705.jpg',
    badge: 'Hot',
    isFavorite: false,
    rating: 4.9,
    reviewCount: 128,
    reviews: MOCK_REVIEWS,
  },
  {
    id: '2',
    name: 'AirPods Pro',
    description: 'Active Noise Cancellation',
    price: 6499,
    badge: 'Best Deal',
    image: '/src/assets/images/product_airpods_pro_1793437531494.jpg',
    isFavorite: true,
    rating: 4.8,
    reviewCount: 85,
    reviews: MOCK_REVIEWS.slice(0, 2),
  },
  {
    id: '3',
    name: 'Smart TV 55"',
    description: '4K UHD • Android TV',
    price: 12999,
    badge: 'Top Rated',
    image: '/src/assets/images/product_smart_tv_1793437532274.jpg',
    isFavorite: false,
    rating: 4.7,
    reviewCount: 56,
    reviews: [MOCK_REVIEWS[0], MOCK_REVIEWS[2]],
  },
  {
    id: '4',
    name: 'Laptop Backpack',
    description: 'Stylish & Durable',
    price: 499,
    badge: 'New',
    image: '/src/assets/images/product_laptop_backpack_1793437532736.jpg',
    isFavorite: false,
    rating: 4.5,
    reviewCount: 210,
    reviews: [MOCK_REVIEWS[1]],
  },
  {
    id: '5',
    name: 'Samsung Galaxy S24',
    description: '256GB • AI Features • Phantom Black',
    price: 17499,
    badge: 'Best Deal',
    image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?q=80&w=512&auto=format&fit=crop',
    isFavorite: false,
    rating: 4.8,
    reviewCount: 94,
    reviews: MOCK_REVIEWS,
  },
  {
    id: '6',
    name: 'PS5 Console',
    description: '825GB • Digital Edition',
    price: 11999,
    badge: 'New Arrivals',
    image: 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?q=80&w=512&auto=format&fit=crop',
    isFavorite: false,
    rating: 4.9,
    reviewCount: 342,
    reviews: MOCK_REVIEWS.slice(1),
  },
  {
    id: '7',
    name: 'Coffee Maker',
    description: 'Automatic Espresso Machine',
    price: 3499,
    badge: 'Top Rated',
    image: 'https://images.unsplash.com/photo-1580915411954-282cb1b0d780?q=80&w=512&auto=format&fit=crop',
    isFavorite: false,
    rating: 4.6,
    reviewCount: 45,
    reviews: [MOCK_REVIEWS[2]],
  },
  {
    id: '8',
    name: 'Running Shoes',
    description: 'Lightweight & Breathable',
    price: 1299,
    badge: 'New',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=512&auto=format&fit=crop',
    isFavorite: false,
    rating: 4.4,
    reviewCount: 88,
    reviews: MOCK_REVIEWS.slice(0, 1),
  },
];
export interface Order {
  id: string;
  date: string;
  items: Product[];
  total: number;
  status: 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';
  trackingStep: number; // 1: Processing, 2: Shipped, 3: Delivered
}

export const MOCK_ORDERS: Order[] = [
  {
    id: 'PSL12345678',
    date: 'Oct 31, 2026',
    items: [PRODUCTS[2]], // Smart TV
    total: 13523,
    status: 'Processing',
    trackingStep: 1,
  },
  {
    id: 'PSL87654321',
    date: 'Oct 28, 2026',
    items: [PRODUCTS[0], PRODUCTS[3]], // iPhone + Backpack
    total: 20523,
    status: 'Shipped',
    trackingStep: 2,
  },
  {
    id: 'PSL11223344',
    date: 'Oct 20, 2026',
    items: [PRODUCTS[1]], // AirPods
    total: 6524,
    status: 'Delivered',
    trackingStep: 3,
  }
];
