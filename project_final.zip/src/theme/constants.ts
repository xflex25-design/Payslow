export const COLORS = {
  primary: '#F20B3A',
  accentPink: '#FFF0F3',
  background: '#FFF9F7',
  card: '#FFFFFF',
  text: '#171717',
  secondaryText: '#858585',
  navBackground: '#000000',
  inactiveIcon: '#929292',
  border: '#EEEEEE',
  divider: 'rgba(0,0,0,0.06)',
};

export const SPACING = {
  xs: '4px',
  sm: '8px',
  md: '16px',
  lg: '24px',
  xl: '32px',
};
