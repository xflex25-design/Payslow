import os
import zipfile

def zip_project(output_filename):
    exclude_dirs = {'node_modules', '.git', 'dist', '.aistudio'}
    exclude_files = {output_filename, 'project.tar.gz', 'project.zip', 'project_clean.zip'}

    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk('.'):
            # Prune excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                if file in exclude_files:
                    continue
                file_path = os.path.join(root, file)
                # Avoid zipping the public folder's own zip files if they exist
                if 'public/project' in file_path:
                    continue
                zf.write(file_path, os.path.relpath(file_path, '.'))

if __name__ == '__main__':
    zip_project('project_final.zip')
    if not os.path.exists('public'):
        os.makedirs('public')
    os.rename('project_final.zip', 'public/project_final.zip')
    print("Done")
